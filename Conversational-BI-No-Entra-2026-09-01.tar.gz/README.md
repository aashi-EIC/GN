# Conversational BI — No Authentication Edition

This package contains the Conversational BI React frontend and Node.js BFF with all Microsoft
identity integration removed. It opens directly as a shared workspace and sends requests to the
BFF without browser credentials.

> Security warning: this edition has no user authentication or user-level authorization. Do not
> expose it directly to the public internet. Protect it with a trusted network boundary, gateway,
> VPN, or another client-managed access control layer.

## Requirements

- Node.js 22 LTS or newer
- npm 10 or newer
- An MCP endpoint that accepts either no credentials or a server-side API key

## Local setup

From the repository root:

```powershell
npm.cmd ci
Copy-Item frontend/.env.example frontend/.env
Copy-Item backend/.env.example backend/.env
```

Configure `VITE_API_BASE_URL` in `frontend/.env` and the MCP settings in `backend/.env`, then run:

```powershell
npm.cmd run dev --workspace backend
npm.cmd run dev --workspace frontend
```

The BFF runs at <http://localhost:3000> and the frontend at <http://localhost:5173> by default.

## MCP credentials

Set `MCP_AUTH_MODE=none` for an endpoint that requires no credentials, or set
`MCP_AUTH_MODE=api-key` with `MCP_API_KEY_HEADER` and `MCP_API_KEY_VALUE`. API keys belong only in
the BFF environment and are never sent to the browser.

## Frontend container

```powershell
docker compose --env-file frontend/.env -f frontend/docker-compose.frontend.yml up --build -d
```

The production container reads `VITE_API_BASE_URL` and `VITE_API_TIMEOUT_MS` at startup, so one
image can be promoted between Kubernetes environments.

## Quality checks

```powershell
npm.cmd run check
```

Sessions and settings use process-local repositories. Add client-owned persistent storage before
running multiple BFF replicas.
